package classicmodels;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="payments", schema = "`classicmodels`") 
public class Payments  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3600423439843707314L;
	private String checkNumber;
	private Customers customerNumber;
	private Date paymentDate;
	private double amount;
	
		public Payments() {
	}
		
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	@Id
	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}
	
	@ManyToOne
	@JoinColumn(name="customerNumber", referencedColumnName = "customerNumber")
	public Customers getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(Customers customerNumber) {
		this.customerNumber = customerNumber;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	

	


	
}
