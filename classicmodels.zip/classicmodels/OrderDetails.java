package classicmodels;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="orderdetails", schema = "`classicmodels`") 
public class OrderDetails  implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -2101055076810967889L;
	private Orders orderNumber;
	private Products productCode;
	private int quantityOrdered;
	private double priceEach;
	private int orderLineNumber;
	public OrderDetails() {}

	@Id
	@ManyToOne (cascade = CascadeType.MERGE)
	@JoinColumn (name = "orderNumber", referencedColumnName = "orderNumber")
	public Orders getOrderNumber() {
		return orderNumber;
	}
	
	public void setOrderNumber(Orders orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	@Id
	@ManyToOne (cascade = CascadeType.MERGE)
	@JoinColumn (name = "productCode", referencedColumnName = "productCode")
	public Products getProductCode() {
		return productCode;
	}
	public void setProductCode(Products productCode) {
		this.productCode = productCode;
	}
	public int getQuantityOrdered() {
		return quantityOrdered;
	}
	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}
	
	public double getPriceEach() {
		return priceEach;
	}
	public void setPriceEach(double priceEach) {
		this.priceEach = priceEach;
	}
	public int getOrderLineNumber() {
		return orderLineNumber;
	}
	public void setOrderLineNumber(int orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}
	
	



	
	

	
}
