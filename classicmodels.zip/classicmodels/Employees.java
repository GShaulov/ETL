package classicmodels;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="employees" , schema = "`classicmodels`")
public class Employees  implements Serializable{
	private static final long serialVersionUID = -3994732245081805668L;
	
	private int employeeNumber;
	private String lastName;
	private String firstName;
	private String extension;
	private String email;
	private Offices officeCode;
	private Employees reportsTo;
	private String jobTitle;
	
	public Employees(){

	}


	
//	public Employees(Employees employee){
//		this.employeeNumber = employee.getEmployeeNumber();
//		this.lastName=employee.getLastName();
//		this.firstName=employee.getFirstName();
//		this.email=employee.getEmail();
//	}

	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	@Id
	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	
	@ManyToOne (cascade = CascadeType.MERGE)
	@JoinColumn (name = "officeCode", referencedColumnName = "officeCode")
	public Offices getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(Offices officeCode) {
		this.officeCode = officeCode;
	}

	@ManyToOne
	public Employees getReportsTo() {
		return reportsTo;
	}

	
	public void setReportsTo(Employees reportsTo) {
		this.reportsTo = reportsTo;
	}
	
}
